<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset ="UTF-8">
    <title>lenscare</title>
    <link rel="stylesheet" href="gamesstyle.css">
</head>
<body>
    <div class ="mid-text">
        <h2> start game</h2>
</div>
<div class= "line line-1">
    <div class ="wave wave1" style="background-color: lightblue"> </div>
    </div>
    <div class= "line line-2">
    <div class ="wave wave2" style="background-color: blue"> </div>
    </div>
    <div class= "line line-3">
    <div class ="wave wave3" style="background-color: yellow"> </div>
    </div>
</div>
</body>
</html>
    
