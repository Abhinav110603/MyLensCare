<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Eye Games</title>
    <link rel="stylesheet" href="style1.css" />
  </head>
  <body>
    <div class="ab">
        <center>
    <header>
        <h2>lenscare</h2>
    <div class="header"></div>
</header>
<nav>
<h2>hey,let's test your eyes</h2>
    <div class ="nav"> </div>
</nav>
</center>
</div>
    <section>
        <h1><a href="" target="_blank">start test</a></h1>
        <div class="wave wave1"></div>
        <div class="wave wave2"></div>
        <div class="wave wave3"></div>
        <div class="wave wave4"></div>
      </section>
      <div id="side-bar-left"></div>
      <div id ="main"></div>

     <div id="footer"></div>
  </body>
  </html>