<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <style>
    .log {
      border-radius: 90%;
    }
    
    </style>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>LensCARE</title>
  <link rel="icon" type="" sizes="16x16" href="Create_an_abstract_concept_logo_for_Lens_Care_.jpg">
  <meta content="" name="description">
  <meta content="" name="keywords">

 
  <link href="Create_an_abstract_concept_logo_for_Lens_Care_.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  </head>
  <body>
    <h2>Emergency Eye Care</h2>

  </body>
  </html>